Useful Tools
===========

autoban.py
----------

Automatically ban IPs that try to brute force crack the server.

See https://github.com/shadowsocks/shadowsocks/wiki/Ban-Brute-Force-Crackers
